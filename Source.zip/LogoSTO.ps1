﻿Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.speech
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName presentationCore
[System.Windows.Forms.Application]::EnableVisualStyles()

$driveletter = $pwd.drive.name
$root = "$driveletter" + ":"
 
$img = [system.drawing.image]::FromFile(".\Source\LogoSTO.gif")
$pictureBoxBackGround = new-object Windows.Forms.PictureBox #permet d'afficher un gif
$pictureBoxBackGround.width = $img.width 
$pictureBoxBackGround.height = $img.height
$pictureBoxBackGround.Image = $img #contient l'image gif de background
$pictureBoxBackGround.AutoSize = $true 

$Form = New-Object System.Windows.Forms.Form
#$Form.Text = "Chargement en cours"
$Form.Width = $img.Width
$Form.height = $img.height
$Form.MaximizeBox = $false
$Form.icon = New-Object system.drawing.icon (".\Source\Icone.ico") 
$Form.TopMost = $true
$Form.AutoSize = $false
$Form.FormBorderStyle = 'none'
$Form.StartPosition = "CenterScreen"

$chargement = New-Object System.Windows.Forms.label
$chargement.Location = New-Object System.Drawing.Point(0,0)
$chargement.AutoSize = $true
$chargement.width = 150
$chargement.height = 25
$chargement.Font= 'Centau,12'
$chargement.ForeColor='white'
$chargement.BackColor = 'black'
$chargement.TextAlign = 'Middleleft'
$chargement.Text = "Chargement en cours..."
#$Form.controls.add($chargement)

$Form.controls.AddRange(@($pictureBoxBackGround))
$Form.ShowDialog() | out-null