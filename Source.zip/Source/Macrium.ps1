Add-Type -AssemblyName Microsoft.VisualBasic
function Preverifchoco 
{
    $chocoexist = $false
    $chocopath = Test-Path C:\ProgramData\chocolatey
    if ($chocopath -eq $true)
    {
       $chocoexist = $true 
    } 
    return $chocoexist
}

function Postverifchoco 
{
    $chocopath = Test-Path C:\ProgramData\chocolatey
    if ($chocopath -eq $false)
    {
        $ErrorMessage = $_.Exception.Message
        Write-Warning "Choco n'a pas pu s'installer !!!! $ErrorMessage"
    }
}

function chocoinstall
{
    $chocoexist = Preverifchoco
    if($chocoexist -eq $false)
    {
        Invoke-WebRequest https://chocolatey.org/install.ps1 -UseBasicParsing | Invoke-Expression | Out-Null
        $env:Path += ";C:\ProgramData\chocolatey" #permet de pouvoir installer les logiciel sans reload powershell
        Postverifchoco
    }
    else
    {
        choco install reflect-free -y | Out-Null
    }   
}

$policy = Get-ExecutionPolicy
Set-ExecutionPolicy Unrestricted -Force
chocoinstall 
Set-ExecutionPolicy $policy
[Microsoft.VisualBasic.Interaction]::MsgBox("Macrium est installé",'OKOnly,SystemModal,Information', "Installation Macrium") | Out-Null